#1A
a = [
    [1, 5, 9],
    [8, 5, 2],
    [3, 6, 7]
]
print(a)

#1B
a = []

for i in range(2):
    ls = list(map(int, input().split()))
    a.append(ls)
print(a)

#1C
n = int(input())

a = []
k = 0
for i in range(n):
    ls = list(map(int, input().split()))
    for num in ls:
        if num < 0:
            k += 1
print(k)

#1D
n, m = map(int, input().split())
a = []
for i in range(n):
    ls = list(map(int, input().split()))
    a.append(ls)

for i in range(n):
    print(a[i][::-1])

#2A
n, m = map(int, input().split())
a = []

for i in range(n):
    ls = list(map(int, input().split()))
    a.append(ls)

for i in range(n):
    for j in range(m):
        if (i + j) % 2 == 0:
            print(a[i][j] + 1, end=" ")
        else:
            print(a[i][j] - 1, end=" ")
    print()

#2B
n, m = map(int, input().split())
a = []
mx = -1111
for i in range(n):
    ls = list(map(int, input().split()))
    if max(ls) > mx:
        mx = max(ls)
    a.append(ls)

for i in range(n):
    for j in range(m):
        if a[i][j] == mx:
            print(i, ":", j)

#3A
a = []
row = 0
column = 0
for i in range(8):
    ls = list(input())
    if "R" in ls:
        row = i
        column = ls.index('R')
    a.append(ls)

for i in range(8):
    for j in range(8):
        if (i == row or j == column) and a[i][j] != 'R':
            print("!", end=" ")
        else:
            print(a[i][j], end=" ")
    print()


