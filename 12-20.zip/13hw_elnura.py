#1A
n = list(map(int, input().split()))
prev = n[0]
ans = []
for num in n[1:]:
    if num > prev:
        ans.append(num)
    prev = num
print(*ans)

#1B - my
n = list(map(int, input().split()))
mx = max(n)

if mx % 2 == 0:
    print(mx)
else:
    print("error")

#1B - decode
n = list(map(int, input().split()))
even = []
for i in n:
    if i % 2 == 0:
        even.append(i)
if even:
    print(max(even))
else:
    print("error")

#2A
d = {
    "OOP": [81, 88, 72, 97],
    "ICT": [78, 69, 86, 98],
    "MATH": [65, 69, 78, 98],
    "PHYSICS": [87, 99, 66, 70]}

for key in d:
    d[key] = sum(d[key]) / len(d[key])
print(d)

#2B
s = input()
first = s.index("h")
second = s.rindex("h")
print(s[:first] + s[second:first:-1] + s[second:])

#3A
n = list(map(int, input().split()))
odd = []
for num in n:
    if num % 2 == 1:
        odd.append(num)
if odd:
    mx = max(odd)
    sum = 0
    for num in str(mx):
        sum += int(num)
    print(f"Num: {mx}, Sum: {sum}")

#3B
n = int(input())
m = int(input())

cpp = set()
pyth = set()

for i in range(n):
    name = input()
    cpp.add(name)
for i in range(m):
    name = input()
    pyth.add(name)

res = pyth.symmetric_difference(cpp)
print(len(res))


