#1A
a, b = map(int, input().split())
d = dict()

for key in range(a, b+1):
    d[key] = key**2
print(d)

#1B
d = {
 "OOP": [77, 88, 99, 66],
 "ICT": [100, 98, 99, 96]}

for key in d:
    for num in d[key]:
        print(key, ":", num)

#2A
words = input().split()
d = dict()

for i in words:
    print(d.get(i, 0), end=" ")
    d[i] = d.get(i, 0) + 1

#2B
n = input()
d = dict()

for char in n:
    d[char] = d.get(char, 0) + 1
print(d)

#3A
n = int(input())
d = dict()

for i in range(n):
    s = input().split()
    country = s[0]
    for city in s[1:]:
        d[city] = country

m = int(input())
for i in range(m):
    city = input()
    print(d[city])

#3B
n = int(input())
d = dict()

for i in range(n):
    f, s = input().split()
    d[f] = s

m = input()
for k, v in d.items():
    if k == m:
      print(v)
    elif v == m:
        print(k)