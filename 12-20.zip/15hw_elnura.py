#1A
def power(a, n):
    print(a**n)

a = int(input())
n = int(input())
power(a, n)

#1B
def leap_year(year):
    if year % 4 == 0 and year % 100 != 0 or year % 400 == 0:
        return True
    return False

year = int(input())
if leap_year(year):
    print("Yes")
else:
    print("No")

#2A
def nod(a, b):
    while True:
        reminder = a % b

        if reminder == 0:
            return b

        a = b
        b = reminder

a, b = map(int, input().split())
print(nod(a, b))

#2B
def sum_m(a):
    s = sum(a) / len(a)
    return s

a = list(map(int, input().split()))
print(sum_m(a))

#3A
def sum_d(num):
    res_sum = 0
    num = abs(num)

    while num > 0:
        res_sum += num % 10
        num //= 10
    return res_sum

nums = list(map(int, input().split()))
print(*sorted(nums, key=sum_d))



