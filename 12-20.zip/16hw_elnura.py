#1
def rev(num, res=0):
    if num == 0:
        return res
    else:
        return rev(num // 10, res * 10 + num % 10)

n = int(input())
print(rev(n))

#2
def power(x, y):
    if y == 0:
        return 1
    else:
        return x * power(x, y-1)

x, y = int(input()), int(input())
print(power(x, y))

#3
def mono_seq(len, num=1, cnt=0):
    if len == 0:
        return
    elif cnt < num:
        print(num, end="")
        mono_seq(len-1, num, cnt+1)
    else:
        mono_seq(len, num+1, 0)

k = int(input())
print(k)
mono_seq(k)
