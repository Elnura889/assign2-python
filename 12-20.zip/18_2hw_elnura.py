#1
def check():
    s = input()
    try:
        f = open(s, 'r')
        for line in f.readlines()[:5]:
            print(line, end=" ")
        return
    except:
        check()
check()

#2
f = open('ethics.txt', 'r')

file = f.readlines()

for i in range(len(file)):
    if i % 2 == 0:
        print(file[i], end=" ")
for i in range(len(file)):
    if i % 2 == 1:
        print(file[i], end=" ")

#3
import os, shutil
f = open('ethics.txt', 'r')
new_file = open('newfile.txt', 'w')

file = f.readlines()

for i in range(6):
    new_file.write(file[i])

new_file.close()

for i in range(1, 4):
    shutil.copyfile("new_ethics.txt", f"new_ethics{i}.txt")
    os.mkdir(f"ethics{i}")
    shutil.move(f"new_ethics{i}.txt", f"ethics{i}")

os.remove("new_ethics.txt")
