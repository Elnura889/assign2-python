#1A
n, m = map(int, input().split())
a = []
mx = -1111
mx_row = 0
mx_col = 0

for i in range(n):
    ls = list(map(int, input().split()))
    ls_mx = max(ls)
    if ls_mx > mx:
        mx = ls_mx
        mx_row = i
        mx_col = ls.index(ls_mx)
print(mx_row, mx_col)

#2A
n, m = map(int, input().split())
a = []

for i in range(n):
    ls = list(map(int, input().split()))
    a.append(ls)

for row in a[::-1]:
    print(*row[::-1])

#3A
n = int(input())
matrix = [['.' for i in range(n)]for j in range(n)]
middle = n // 2 #для нахождения середины по индексу
for i in range(n):
    matrix[middle][i] = "*" #для выводения * по строчкам середина
    matrix[i][middle] = '*' #для выводения * по столбцам
    matrix[i][i] = '*' #для выводения * по левой горизонтали
    matrix[i][n-i-1] = '*' #для выводения * по правой горизонтали
for row in matrix:
    print(*row)

