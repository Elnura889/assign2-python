#1
class University:
    def __init__(self, off_name, location):
        self.off_name = off_name
        self.location = location

class Student(University):
    def __init__(self, off_name, location, full_name, speciality):
        super().__init__(off_name, location)
        self.full_name = full_name
        self.speciality = speciality

class Professor(University):
    def __init__(self, off_name, location, full_name, subject):
        super().__init__(off_name, location)
        self.full_name = full_name
        self.suject = subject

#2A
class Table:
    def __init__(self, length, width, height):
        self.length = length
        self.width = width
        self.height = height

class DeskTable(Table):
    def square(self):
        return self.length * self.width

length, width, height= map(float, input().split())
d = DeskTable(length, width, height)
print(d.square())

#3
class Table:
    def __init__(self, length, width, height):
        self.length = length
        self.width = width
        self.height = height

class DeskTable(Table):
    def square(self):
        return self.length * self.width

class ComputerTable(DeskTable):
    def square(self, monitor_area):
        return super().square() - monitor_area

length, width, height, monitor= map(float, input().split())
d = ComputerTable(length, width, height)
print(d.square(monitor))

