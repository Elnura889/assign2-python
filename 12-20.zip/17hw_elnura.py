#1A
d = {
    "a": 1,
    "b": 2,
    "c": 3}
key = input()
try:
    value = d[key]
except KeyError:
    value = "That key does not exist"
print(value)

#1B
x, y = map(int, input().split())
mn = x if x < y else y
print(mn)

#2A
n = list(map(int, input().split()))
for num in n:
    if num % 3 == 0 and num % 5 == 0:
        raise Exception("Такое число присутствует")
raise Exception("Такое число отсутствует")

#2B
a = int(input())
b = int(input())
c = int(input())
if a * b == c:
    raise Exception("True")
raise Exception("False")

#3A
a = int(input())
b = input()
c = int(input())

try:
    if b == '/':
        value = a / c
    elif b == "*":
        value = a * c
except ZeroDivisionError:
    value = "Ошибка: деление на ноль"

print(value)

#3B
def check(num):
    if num == 0:
        return False
    return True if num % 10 % 3 == 0 else check(num // 10)

n = int(input())
print(check(n))

