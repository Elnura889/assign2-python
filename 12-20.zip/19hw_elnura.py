#1A
import re
a = input()
ans = re.findall(r'\d{2}-\d{2}-\d{4}', a)
print(ans)

#1B
import re
a = input()
ans = re.findall(r'\b[AEIOUYaeiouy]\w+\b', a)
print(ans)

#2A
import re
a = input()
print(bool(re.search(r'\d$', a)))

#2B
import re
s = input()
num = re.search(r'\d', s)

print(num.group(0))
print("Index:", num.end())

#3A
import re
s = input()
ans = re.findall(r'\b[A-Za-z]{5}\b', s)
print(ans)

#3B
import re
def case(s):
    a = re.search(r'[a-z][A-Z]', s)
    return s[:a.start()+1]+'_'+s[a.end()-1:]
s = input()
print(case(s))

